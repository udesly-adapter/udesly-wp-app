<?php

namespace Udesly\Admin;

defined( 'ABSPATH' ) || exit;

final class Admin {

}