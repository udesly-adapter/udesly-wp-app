<?php

namespace Udesly\Core;

defined( 'ABSPATH' ) || exit;

class Activator {

    static function activate_plugin() {

    }

}
