<?php

namespace Udesly\Core;

defined( 'ABSPATH' ) || exit;

class Deactivator {

    static function deactivate_plugin() {

    }

}
